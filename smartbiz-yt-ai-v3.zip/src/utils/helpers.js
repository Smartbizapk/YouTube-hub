// Placeholder for helpers.js
